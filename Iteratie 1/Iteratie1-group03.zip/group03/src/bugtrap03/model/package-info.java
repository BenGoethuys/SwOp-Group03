/**
 * The package contains the controller of the system.
 */
@capsules.Capsule(exportKeyword = bugtrap03.bugdomain.DomainAPI.class, friends = {"bugtrap03.bugdomain"})
package bugtrap03.model;