package bugtrap03.bugdomain;

/**
 * This is an annotation for our API
 *
 * @author Group 03
 */
public @interface DomainAPI {
}
