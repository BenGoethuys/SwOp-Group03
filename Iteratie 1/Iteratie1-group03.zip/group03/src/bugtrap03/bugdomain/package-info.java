/**
 * Package containing all the core classes of the system
 *
 * @author Group 03
 */
@capsules.Capsule(exportKeyword = bugtrap03.bugdomain.DomainAPI.class, friends = {"bugtrap03.model"})
package bugtrap03.bugdomain;