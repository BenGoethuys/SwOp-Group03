package capsulesexample.system.sub2;

public class Subsystem2InternalSubsubclass extends Subsystem2ExportedSubclass {
	
	public void exportedInterfaceMethod() {}
	
	public void run() {}
	
}