package capsulesexample.system;

import java.lang.annotation.Documented;

@Documented
@SystemAPI
public @interface SystemAPI {

}
