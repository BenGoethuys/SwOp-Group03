package capsulesexample.system;

@SystemAPI
public enum ExportedEnum {
	X, Y, Z;
	
	public void internalMethod() {}
}
