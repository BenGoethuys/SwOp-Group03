@Capsule(exportKeyword=SystemAPI.class, friends={"capsulesexample.friend"})
package capsulesexample.system;

import capsules.Capsule;

