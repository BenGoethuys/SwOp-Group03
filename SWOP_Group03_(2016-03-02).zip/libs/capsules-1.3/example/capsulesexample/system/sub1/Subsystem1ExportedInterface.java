package capsulesexample.system.sub1;

import capsulesexample.system.SystemAPI;

@SystemAPI
public interface Subsystem1ExportedInterface {
	
	@SystemAPI
	public void exportedInterfaceMethod();
	
}