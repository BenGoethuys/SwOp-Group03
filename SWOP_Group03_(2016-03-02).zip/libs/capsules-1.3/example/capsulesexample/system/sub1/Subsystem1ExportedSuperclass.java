package capsulesexample.system.sub1;

import capsulesexample.system.SystemAPI;

@SystemAPI
public abstract class Subsystem1ExportedSuperclass implements Subsystem1ExportedInterface {
	
	@SystemAPI
	public void exportedSuperclassMethod() {}
	
}
